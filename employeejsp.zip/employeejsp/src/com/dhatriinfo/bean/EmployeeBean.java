package com.dhatriinfo.bean;
public class EmployeeBean 
{
	private String employeeId;
	private String employeeName;
	private int employeeSlary,employeeLoan;
	private String employeeLoc;
	private int employeeExp;
	private int employeeEmi;
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmployeeSlary() {
		return employeeSlary;
	}
	public void setEmployeeSlary(int employeeSlary) {
		this.employeeSlary = employeeSlary;
	}
	public String getEmployeeLoc() {
		return employeeLoc;
	}
	public void setEmployeeLoc(String employeeLoc) {
		this.employeeLoc= employeeLoc;
	}
	public int getEmployeeLoan() {
		return employeeLoan;
	}
	public void setEmployeeLoan(int employeeLoan) {
		this.employeeLoan=employeeLoan;
	}
	public int getEmployeeExp() {
		return employeeExp;
	}
	public void setEmployeeExp(int employeeExp) {
		this.employeeExp = employeeExp;
	}
	public int getEmployeeEmi() {
		return employeeEmi;
	}
	public void setEmployeeEmi(int employeeEmi) {
		this.employeeEmi = employeeEmi;
	}
	

}

