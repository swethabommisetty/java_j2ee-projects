package com.dhatriinfo.bean;

public class SampleBean {

}
